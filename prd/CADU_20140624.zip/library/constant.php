<?php
	define("SAL", 'CadCCrs');
?>